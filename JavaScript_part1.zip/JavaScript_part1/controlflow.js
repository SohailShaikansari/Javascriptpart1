// 1. if else
// let hour = 10;
// if (hour>= 6 && hour < 12){
//     console.log('good morning');
// }
// else if (hour >= 13 && hour < 18){
//     console.log('Good Afternoon');
// }
// else {
//     console.log('Go home');
// }

// 2. Switch and case
// let role = 'guest';

// switch (role) {
//     case 'guest':
//         console.log('guest user');
//         break;
//     case 'moderator':
//         console.log('Moderator');
//         break;
//     default:
//         console.log('Unknown User')
  
// }

// 3. For Loop

// for (let i = 0; i < 5; i++){
//     console.log('Hello World', i);
// }


// 4. While loop
// for (let i = 0; i < 5; i++){
//          console.log('Hello World', i);
// }
// let i = 0;
// while(i < 5){
//     console.log(i);
//     i++;
//     console.log(i);
// }

// 5. do while loop
// let i = 0;
// do{
//     if (i % 2 !== 0) console.log(i);
//     i++;
// } while(i <= 5)


// 6. Infinite Loops
// let i = 0
// while(i < 10) {

//     console.log(i);
    //i++;
// }

// 7. For-in Loops
// const person = {
//     name : 'Josh',
//     age : 30
// };

// for (let key in person) {
//     console.log(key, person[key]);
//    }

// 8. For-of Loops
// let colors = ['red', 'blue', 'green'];
// for (let color of colors){
//         console.log(color);
// }
//for (let index in colors) console.log(index,colors[index]);


// 9. break and continue
// let i = 0;
// while (i <= 10){
    //if(i === 5) break;
//     if(i % 2 === 0) {
//         i++;
//         continue;
//     }
//     console.log(i);
//     i++;
// }

// 10. Ex-1 Maximum of two numbers
// function max (a,b) {
//     if (a>b) return a;
//     else return b;
// }
// console.log(max (10, 2));

// 11. Ex-2 Landscape or portrait
// function islandscape(width, height){
//     return (width>height);
// }
// console.log(islandscape(800, 600));

// 12. Ex-3 FizzBuzz
// function fizzbuzz(input) {
//     if (typeof input !== 'number') return NaN;
//     if ((input%3 === 0) && (input%5 === 0)) return 'FizzBuzz';
//     if ((input%3 !== 0) || (input%5 !== 0)) return input ;
//     if (input % 3 === 0)  return 'Fizz';
//     if (input % 5 === 0) return 'Buzz';
// }
// const output = fizzbuzz(7);
// console.log(output);

// 13. Ex-4 Demerit points
// function checkspeed(speed){
//     const speedlimit = 70;
//     const kmperpoint = 5;
//     if (speed <= speedlimit + kmperpoint) 
//     console.log('O.K.');
//     else{
//         const points =Math.floor((speed - speedlimit) / kmperpoint);
//         if (points >= 12)
//         console.log('License Suspended');
//         else
//         console.log('points',points);
//     } 
// }
// let output = checkspeed(80);
// console.log(output);


// 14. Ex-5 Even and Odd Numbers
// function showNumbers(limit){
//     let i = 0;
//     while(i <= limit){
//         if (i % 2 === 0) console.log(i,"EVEN");
//         else console.log(i,"ODD")
//         i++;
//     }
// }
// showNumbers(10);


// 15. Ex-6 Count Truthy
// const array = [0, null, undefined, '', 2, 3];
// function counttruthy(array){
//     let count = 0;
//     for (let value of array)
//     if (value)
//     count++;
//     return count;

// } 
// console.log(counttruthy(array));


// 16. Ex-7 :String Properties
// const movie = {
//     title: 'a',
//     releaseYear: 2018,
//     rating: 4.5,
//     director: 'b'
// };
// function showproperties(obj) {
//     for (let key in movie)
//     if(typeof obj[key] === 'string')
//     console.log(key,obj[key]);

// }
// showproperties(movie);

// 17. Ex-8: Sum of multiples of 3 and 5
//  function sum(limit) {
//      let sum = 0;
//      for(let i = 0; i <= limit; i++) {
//          if (i % 3 === 0 || i % 5 === 0) 
//          sum += i;
//          }
//         return sum;
// }
//  console.log(sum(10));

//  18. Ex-9: Grade
// const marks = [80, 80, 50];

// function calculategrade(marks) {

//     let sum = 0;
//     for (let mark of marks) {
//         sum += mark;
//         }
//     let avg = sum/marks.length;
//     if (avg < 60) return 'F';
//     if (avg < 70) return 'D';
//     if (avg < 80) return 'C';
//     if (avg < 90) return 'B';
//     return A;

// }
// console.log(calculategrade(marks));

// 19. Ex-10: Stars
//  function showStars(rows) {
//      for (let row =1; row <= rows; row++) {
//        let pattern = '';
//        for(let i = 0; i< row; i++)
//         pattern += '*'
//         console.log(pattern);
//     }
     

//  }
//  showStars(5)

// 20: Ex-11 : Prime Numbers
// function showPrimes(limit) {

//     for(let number=2; number<=limit;number++) {
//         let isPrime = true;
//         for(let factor = 2; factor < number; factor++ ) {
//             if(number % factor === 0) {
//                 isPrime = false;
//                 break;
//             }
//         }
//         if (isPrime) console.log(number);
//     }
// }
// showPrimes(20);