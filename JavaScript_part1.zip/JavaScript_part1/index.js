
//comment or Documentation
console.log('Hello World');
