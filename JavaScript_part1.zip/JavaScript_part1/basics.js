//BASICS


// 1. VARIABLES
//let name = 'Mosh';
//console.log(name);


// 2. CONSTANTS
const interestRate = 0.3;
//interestRate = 1;
console.log(interestRate);

// 3. PRIMITIVE TYPES
//let Name = 'Sohail';  //String Literal
//let age = 25;       //Number Literal
let isApproved = true;//Boolean literal
let firstname = undefined;// same as let firstname;
//let lastname = null; //explicitly clear the value of a variable

// 4. DYNAMIC TYPING
//typeof ---> Reserved Keyword

// 5. OBJECTS
// let person = {
//     name: 'Mosh',
//     age: 30,
// };
// person.name = 'John';  //DOT NOTATION
// person['age'] = 24;    //BRACKET NOTATION
// console.log(person['age']);

// 6. ARRAYS
let selectedColors = ['red', 'blue'];
selectedColors[2] = 'grey';
console.log(selectedColors.length);

// 7. FUNCTIONS
// function greet(name, lastname) {
//     console.log('hello ' + name +""  + lastname);
// }
// greet('john','Wick');

// function square(num){
//     return num*num;
// }
// let number = square(4);
// console.log(number); // (or) console.log(square(2));



//OPERATORS

// 1. ARITHMETIC OPERATORS
// let x = 10;
// let y = 2;
// let z = x + y;
// console.log(z);
// console.log(x + y);
// console.log(x - y);
// console.log(x / y);
// console.log(x % y);
// console.log(x * y);
// console.log(x ** y);
// console.log(x);
// console.log(++x);
// console.log(x++);
// console.log(y);
// console.log(y--);
// console.log(--y);



// 2. ASSIGNMENT OPERATORS
// let x = 10;
// x +=5;
// console.log(x);

// 3. COMPARISION OPERATORS
let x = 1;

//Relational Operators
// console.log(x > 1);
// console.log(x >= 1);
// console.log(x < 1);
// console.log(x <= 1);

//Equality Operators
// console.log(x===1);
// console.log(x!==2);

//Strict Equality Operators
// console.log(1===1);
// console.log('1'===1);

//Lose Equality Operators
// console.log(1==1);
// console.log('1'==1);
// console.log(true==1);
// console.log(2==1);

//Ternary or Conditional operator
// let points = 100;
// let eligibilty = points > 90 ? 'gold':'silver';
// console.log(eligibilty);

//Logical Operators
//logical and(&&)
//returns true if both operands are true
//logical or(||)
//returns true if one of the operands in true
//logical not(!)


// Logical operators with non-booleans ---> Falsy or truthy 
// false || 1|| 2;  ---> Short circuit 

//Bitwise Operators(|,&,)

//Operator Precedence

//Exercise
let a = 'red';
let b = 'blue';
let temp = a;
a = b;
b = temp;

console.log(a);
console.log(b);
