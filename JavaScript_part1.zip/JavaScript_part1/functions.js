// 1.Function declaration (vs) Expression
// // Function declaration
// function walk() {
//     console.log('walk')
// }

// // Function Expression(Anonymous Function Expression)
// let run = function () {
//     console.log('run');
// };
// let move = run;
// run();
// move();
// // Named Function Expression
// // let run = function walk () { 
// //     console.log('run');
// // };

// 2 .Hoisting --> It is the process of moving function declarations
// to the top of the file by Javascript engines

// 3. Arguments
// function sum() {
//     let total = 0;
//     for (let value of arguments)
//         total += value;
//     return total;
// }
// console.log(sum(1, 2, 3, 4, 5))

// 4. The Rest Operator

// function sum(...args) {     // This is Rest operator not spread operator
//     return args.reduce((a, b) => a + b);
// }
// console.log(sum(1, 2, 3, 4, 5))


// function sum(discount, ...prices) {
//     const total = prices.reduce((a, b) => a + b);
//     return total * (1 - discount);
// }
// console.log(sum(0.1, 20, 30, 1));

// 5. Default Parameters
// function interest(principal, rate = 3.5, years = 5) {
//     return principal * rate / 100 * years;
// }
// console.log(interest(10000));


// 6. Getters and setters
// getters => access properties
//setters => change(mutate) properties
// const person = {
//     firstName: 'Mosh',
//     lastName: 'Hamedani',
//     get fullName() {
//         return `${person.firstName} ${person.lastName}`
//     },
//     set fullName(value) {
//         const parts = value.split(' ');
//         this.firstName = parts[0];
//         this.lastName = parts[1];
//     }
// };
// person.fullName = 'John Smith';
// console.log(person);

// 7. Try and Catch

// const person = {
//     firstName: 'Mosh',
//     lastName: 'Hamedani',

//     set fullName(value) {
//         if (typeof value !== 'string')
//             throw new Error('Value is not a String');
//         const parts = value.split(' ');
//         if (parts.length !== 2)
//             throw new Error('f name and last name');
//         this.firstName = parts[0];
//         this.lastName = parts[1];
//     }
// };
// try {
//     person.fullName = null;
// }
// catch (e) {
//     alert(e);
// }
// console.log(person);

// 8. Local vs Global Scope

// const color = 'red';
// function start() {
//     const message = 'hi';
//     const color = 'blue';
//     console.log(color);

// }
// function stop() {
//     const message = 'bye';

// }
// start();
// console.log(color);

// 9. Let vs Var

// function start() {
//     for (let i = 0; i < 5; i++) {
//         console.log(i);
//     }
//     console.log(i);
// }


// function start() {
//     for (var i = 0; i < 5; i++)
//         console.log(i);

//     console.log(i);
// }
// start();

// 10. The this Keyword
// 11. Changing the this

