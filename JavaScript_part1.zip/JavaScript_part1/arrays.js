// 2. Adding Elements
// const numbers = [3 , 4];
// numbers.push(5 ,6);
// numbers.unshift(1, 2);
// numbers.splice(2,0,'a','b');
// console.log(numbers);

// 3. Finding Elements
// const numbers = [1, 2, 3, 1, 4];
// console.log(numbers.indexOf(1));
// console.log(numbers.indexOf(1, 2));
// console.log(numbers.lastIndexOf(1));
// console.log(numbers.indexOf(1) !== -1);
// console.log(numbers.includes(1));

// 4. Finding Elements(Reference Types)
// const courses = [
//     {id :1, name : 'a'},
//     {id :2, name : 'b'},
// ];

// //console.log(courses.includes({id : 1, name : 'a'}));
// const course = courses.find(function(element){
//     return element.name === 'a';

// });
// const course = courses.findIndex(function(element){
//     return element.name === 'a';

// });
// console.log(course);

// 5. Arrow Functions
// const courses = [
//     {id: 1, name: 'a'},
//     {id: 2, name: 'b'},
// ];
// const course = courses.find((element) => element.name === 'a');
// console.log(course);

// 6. Removing Elements
// const numbers = [1, 2, 3, 4];
// //End
//  const last = numbers.pop();
//  console.log(last);
//  console.log(numbers);

// //Beginnig
//  const first = numbers.shift();
//  console.log(first);
//  console.log(numbers);

//Middle
// numbers.splice(2, 1);
// console.log(numbers);
// numbers.splice(2, 2);
// console.log(numbers);

// 7. Emptying an array
// let numbers = [1, 2, 3, 4];
// let another = numbers;
//Solution 1
// numbers = [];
// console.log(numbers);
// console.log(another);

//Solution 2
// numbers.length = 0;
// console.log(numbers);
// console.log(another);

//Solution 3 --> Splice method
// numbers.splice(0, numbers.length);
// console.log(numbers);
// console.log(another);

//Solution 4 -->pop method
// while(numbers.length > 0){
//     numbers.pop();
// }
// console.log(numbers);
// console.log(another);


// 8. Combining and Slicing Arrays
//primitives
// const first = [1, 2, 3, 4];
// const second = [5, 6, 7, 8];
// let combined = first.concat(second);
// let sliced = combined.slice(2, 4);
// let slice = combined.slice(2);
// let slicede = combined.slice();
// console.log(combined);
// console.log(slicede);

// const first =[ { id : 1 } ];
// const second=[2, 3];
// first[0].id = 10;
// let combined = first.concat(second);
// let sliced = combined.slice();
// console.log(combined);
// console.log(sliced);

// 9. The spread Operator

// const first = [1, 2, 3, 4];
// const second = [5, 6, 7, 8];
// let combined = [...first, ...second, 'a'];
// let copy = [...combined];
// console.log(combined);

// 10. Iterating an array
// const numbers = [1, 2, 3, 4];
// for (let number of numbers) 
// console.log(number);
// // numbers.forEach(function(number) {
// //     console.log(number);
// // });
// numbers.forEach((number, index) => console.log(number, index));

// 11. Joining Arrays
// const numbers = [1, 2, 3];
// const joined = numbers.join(',');
// console.log(joined);

// const message = 'This is my first message';
// const parts = message.split('');
// console.log(parts);

// const combined = parts.join('-');
// console.log(combined);

// 12. Sorting Arrays
// const numbers = [1, 2, 3];
// numbers.sort();
// console.log(numbers);
// numbers.reverse();
// console.log(numbers);

// const courses = [
//     {id : 1, name : 'Node.js'},
//     {id : 2, name : 'javaScript'},
// ];


// courses.sort(function(a, b) {
//     const nameA = a.name.toUpperCase();
//     const nameB = b.name.toUpperCase();
//     if (nameA < nameB) return -1;
//     if (nameA >nameB) return 1;
//     return 0;
// }
// );
// console.log(courses);

// 13. Testing the elements of an array
// const numbers = [1, 2, 3];
// const allPositive = numbers.every(function(value){
//     return value >= 0;
// });
// console.log(allPositive);
// const atleastOnePositive = numbers.some(function(value){
//     return value >= 0;
// }
// );
// console.log(atleastOnePositive);

// 14. Filtering an Array
// const numbers = [1, -1, 3, 4];
// // const filtered = numbers.filter(function(value){
// //     return value >= 0;
// // }
// // );

// const filtered = numbers.filter((value) => value >= 0);
// console.log(filtered);

// 15. Mapping an Array

// mapping numbers to strings
// const numbers = [1, -1, 3, 4];
// const filtered = numbers.filter((n) => n >= 0);
// const items = filtered.map(n => '<li>' + n + '</li>');
// const html ='<ul>' + items.join('') + '</ul>';
// console.log(html);

// mapping numbers to objects
// const numbers = [1, -1, 3, 4];
// const filtered = numbers.filter((n) => n >= 0);
// const items = filtered.map(n => ({ value: n}));
// console.log(items);

// map and filter functions return a new array, they are chainable
// const numbers = [1, -1, 2, 3];
// const items = numbers
// .filter(n => n >= 0)
// .map(n => ({ value:n }));
// console.log(items);

// 16. Reducing an Array

// const numbers = [1, -1, 2, 3];
// // let sum = 0;
// // for (let n of numbers)
// // sum += n;
// // console.log(sum);
// // cleaner and elegant way to write the above code
// // const sum = numbers.reduce((accumulator, currentValue)=> {
// //     return accumulator + currentValue;
// // }, 0);
// // console.log(sum);


// //we can still make the code shorter


// const sum = numbers.reduce((accumulator, currentValue) => accumulator + currentValue
// );
// console.log(sum);

// 17. Ex-1 : Array from Range
// function arrayFromRange(min, max){
//     const output = [];
//     for (let i =min; i<=max; i++)
//     output.push(i);
//     return output;
// }
// const numbers = arrayFromRange(1 ,4);
// console.log(numbers)

// 18. ex-2 : Includes
// const numbers =[1, 2, 3, 4];
// function includelikefunc(array, searchElement) {
//     for (let element of array)
//     if(element ===searchElement)
//       return true;
//     return false;
// }
// console.log(includelikefunc(numbers, 1));

// 19. Except
// const numbers = [1, 2, 3, 4];
// function except(array, excluded) {
//     const output = [];
//     for(let element of array)
//     if(!excluded.includes(element))
//     output.push(element);
//     return output;
// }
// const output = except(numbers, [1, 2, 3, 4]);
// console.log(output);